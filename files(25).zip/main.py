# ─────────────────────────────────────────────
#  main.py  —  Telegram bot  (aiogram v3)
#
#  Run:  python main.py
# ─────────────────────────────────────────────

import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

from config import BOT_TOKEN
from database import init_db
from engine import add_report, find_nearest_spots

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
)

bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.MARKDOWN)
dp  = Dispatcher(storage=MemoryStorage())


# ── Keyboards ────────────────────────────────────────────────────────────────

def kb_share_location() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📍 Share my location", request_location=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )


def kb_report(spot_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Still free",   callback_data=f"report:free:{spot_id}"),
        InlineKeyboardButton(text="🔴 Full / taken", callback_data=f"report:full:{spot_id}"),
    ]])


# ── Formatters ───────────────────────────────────────────────────────────────

STATUS_EMOJI = {"free": "🟢", "likely_full": "🟡", "full": "🔴"}

TYPE_LABEL = {
    "street":    "Street parking",
    "courtyard": "Courtyard",
    "lot":       "Parking lot",
}


def fmt_spot(rank: int, spot: dict) -> str:
    emoji  = STATUS_EMOJI.get(spot["status"], "🟢")
    kind   = TYPE_LABEL.get(spot["spot_type"], spot["spot_type"])
    name   = spot["name"] if spot["name"] != "Unnamed spot" else kind
    dist   = spot["distance_m"]
    cap    = f" · {spot['capacity']} spaces" if spot["capacity"] else ""
    rpts   = f" · {spot['reports']} report(s)" if spot["reports"] else ""
    warn   = ("\n   ⚠️ _Low certainty — check for barriers_"
              if spot["certainty"] == "low" else "")

    return (
        f"{rank}. {emoji} *{name}*\n"
        f"   📏 {dist} m away  |  {kind}{cap}{rpts}{warn}"
    )


# ── Command handlers ─────────────────────────────────────────────────────────

@dp.message(CommandStart())
async def cmd_start(msg: Message) -> None:
    await msg.answer(
        "🅿️ *Free Parking Finder*\n"
        "━━━━━━━━━━━━━━━━━━━━━\n"
        "I find the nearest *free* parking spots in Minsk & Moscow "
        "using OpenStreetMap + live crowd reports.\n\n"
        "Tap the button below to share your location, "
        "or use /find at any time.\n\n"
        "/help — how it works\n"
        "/stats — database stats",
        reply_markup=kb_share_location(),
    )


@dp.message(Command("help"))
async def cmd_help(msg: Message) -> None:
    await msg.answer(
        "*How it works*\n\n"
        "1️⃣  Share your location.\n"
        "2️⃣  I show the nearest free spots (up to 1.5 km).\n"
        "3️⃣  Each spot gets a live pin on the map.\n"
        "4️⃣  After visiting, tap ✅ *Still free* or 🔴 *Full/taken* "
        "so other drivers know.\n\n"
        "*Status colours*\n"
        "🟢 Likely free\n"
        "🟡 Mixed reports — approach with caution\n"
        "🔴 Confirmed full — hidden from results\n\n"
        "*Reports decay after 20 minutes* so stale info doesn't linger.\n\n"
        "⚠️  *Courtyard spots* are legal grey areas. "
        "Always check for barriers (шлагбаум) before driving in.",
    )


@dp.message(Command("find"))
async def cmd_find(msg: Message) -> None:
    await msg.answer(
        "📍 Share your location and I'll search nearby:",
        reply_markup=kb_share_location(),
    )


@dp.message(Command("stats"))
async def cmd_stats(msg: Message) -> None:
    from database import get_conn
    conn = get_conn()

    total   = conn.execute("SELECT COUNT(*) FROM spots").fetchone()[0]
    by_city = conn.execute(
        "SELECT city, COUNT(*) FROM spots GROUP BY city"
    ).fetchall()
    by_type = conn.execute(
        "SELECT spot_type, COUNT(*) FROM spots GROUP BY spot_type"
    ).fetchall()
    reports = conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
    conn.close()

    city_lines = "\n".join(f"  • {r[0] or 'unknown'}: {r[1]}" for r in by_city)
    type_lines = "\n".join(f"  • {r[0]}: {r[1]}" for r in by_type)

    await msg.answer(
        f"📊 *Database stats*\n\n"
        f"Total spots: *{total}*\n\n"
        f"By city:\n{city_lines}\n\n"
        f"By type:\n{type_lines}\n\n"
        f"Total crowd reports: *{reports}*"
    )


# ── Location handler ─────────────────────────────────────────────────────────

@dp.message(F.location)
async def handle_location(msg: Message) -> None:
    lat = msg.location.latitude
    lon = msg.location.longitude

    await msg.answer("🔍 Searching …", reply_markup=ReplyKeyboardRemove())

    spots = find_nearest_spots(lat, lon)

    if not spots:
        await msg.answer(
            "😕 No free spots found within 1.5 km.\n\n"
            "Possible reasons:\n"
            "• The database hasn't been seeded yet — "
            "run `python osm_fetcher.py` first.\n"
            "• All nearby spots have been reported as full.\n"
            "• Your city isn't in the database yet (add it in config.py).",
        )
        return

    header = f"🅿️ *{len(spots)} free spot(s)* found nearby:\n\n"
    summary = "\n\n".join(fmt_spot(i + 1, s) for i, s in enumerate(spots))
    await msg.answer(header + summary)

    # Send a live pin + report buttons for each result
    for spot in spots:
        await bot.send_location(
            chat_id=msg.chat.id,
            latitude=spot["lat"],
            longitude=spot["lon"],
        )
        await msg.answer(
            f"📍 *{spot['name']}*  —  was this spot free when you arrived?",
            reply_markup=kb_report(spot["id"]),
        )


# ── Callback: crowd report ───────────────────────────────────────────────────

@dp.callback_query(F.data.startswith("report:"))
async def handle_report(cb: CallbackQuery) -> None:
    _, status, spot_id_str = cb.data.split(":")
    spot_id = int(spot_id_str)
    user_id = cb.from_user.id

    add_report(spot_id, user_id, status)

    reply = "✅ Marked as *free* — thank you!" if status == "free" \
        else "🔴 Marked as *full* — thank you!"

    await cb.answer(reply.replace("*", ""))       # popup (plain text)
    await cb.message.edit_reply_markup(reply_markup=None)   # remove buttons


# ── Entry point ──────────────────────────────────────────────────────────────

async def main() -> None:
    init_db()
    logging.info("Bot starting — polling …")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
